"""A text-only toolbar of Nxt commands under test, shown in Part Design."""

from __future__ import annotations

import FreeCADGui as Gui

from ..core.qt import QtCore, QtGui, QtWidgets

NAME = "NxtTesting"
WORKBENCH = "PartDesignWorkbench"
COMMANDS = (("Nxt_BlendFillet", "Nxt fillet"),
            ("Nxt_BlendChamfer", "Nxt chamfer"))


def _toolbar() -> QtWidgets.QToolBar:
    window = Gui.getMainWindow()
    toolbar = window.findChild(QtWidgets.QToolBar, NAME)
    if toolbar is None:
        toolbar = window.addToolBar("Nxt testing")
        toolbar.setObjectName(NAME)
        toolbar.setToolButtonStyle(
            QtCore.Qt.ToolButtonStyle.ToolButtonTextOnly)
        for command, text in COMMANDS:
            action = QtGui.QAction(text, toolbar)
            action.setObjectName(command)
            action.triggered.connect(
                lambda _checked=False, name=command: Gui.runCommand(name))
            toolbar.addAction(action)
    return toolbar


def update(*_args: object) -> None:
    workbench = Gui.activeWorkbench()
    active = workbench is not None and workbench.name() == WORKBENCH
    _toolbar().setVisible(active)


def _later(*_args: object) -> None:
    QtCore.QTimer.singleShot(0, update)


def install() -> None:
    Gui.getMainWindow().workbenchActivated.connect(_later)
    _later()
