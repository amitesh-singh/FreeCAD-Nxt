"""Panel state that survives a restart, in FreeCAD's parameter store.

The dock is created after Qt and FreeCAD's overlay manager restore layout,
so its placement and overlay state must be recorded here.
"""

from __future__ import annotations

import traceback
from typing import Any

import FreeCAD as App

GROUP = "User parameter:BaseApp/Preferences/Mod/Nxt"

DEFAULTS: dict[str, bool | int | float | str] = {
    # First run only: the panel tabs itself beside the stock tree once.
    "Configured": False,
    "Visible": True,
    "Overlay": False,
    # Overlay came from FreeCAD's manager, not the panel's toggle.
    "HostOverlay": False,
    "Floating": False,
    "DockArea": 1,          # Qt.LeftDockWidgetArea
    "FloatX": 0,
    "FloatY": 0,
    "FloatWidth": 0,
    "FloatHeight": 0,
    # "expression" (timeline) or "nested" (the classic tree).
    "PartLayout": "expression",
    # The tree's quick settings; see prefs.py for the values each takes.
    "RowDensity": "normal",
    "ReferenceChips": "problems",
    "UnderConstrainedMarks": True,
    "RowToolTips": True,
    # "nxt" (drawn in the 3D view) or "freecad".
    "OverlayMode": "nxt",
    "ViewOverlay": False,
    "FollowSelection": True,
    "EditOnDoubleClick": True,
    "AttachSketchByPoints": True,
    "SnapToFaces": True,
    "RepairProfiles": True,
    # Look for addon updates after startup (app/update_check.py).
    "CheckAddonUpdates": True,
    "GizmoDefaultsApplied": False,
    # JSON of the drag settings the defaults replaced (gizmos.py).
    "GizmoOriginals": "",
    "FloatingValues": True,
    "TreeEditHidesHandles": False,
    "TreeLines": False,
    "DetailAutoShow": False,
    "HighlightRelated": False,
    "DependencyArrows": False,
    # Quick Mass at the bottom of the 3D view (ui/quick_mass.py).
    "QuickMass": False,
    "QuickMassMaterial": "Steel-Generic",
    "QuickMassUnits": "Internal",
    # Strip width: percent of screen, floored at HeaderMinWidth pixels.
    "HeaderMaxPercent": 18,
    "HeaderMinWidth": 220,
    # Inspector geometry; a size of 0 means never placed.
    "InspectorPinned": False,
    "InspectorTable": False,
    "InspectorX": 0,
    "InspectorY": 0,
    "InspectorWidth": 0,
    "InspectorHeight": 0,
}


def _params() -> Any:
    return App.ParamGet(GROUP)


#: bool before int: bool is a subclass of int, so the order matters.
_ACCESSORS: tuple[tuple[type, str, str], ...] = (
    (bool, "GetBool", "SetBool"),
    (int, "GetInt", "SetInt"),
    (float, "GetFloat", "SetFloat"),
    (str, "GetString", "SetString"),
)


def _accessor(default: object) -> tuple[type, str, str]:
    for kind, getter, setter in _ACCESSORS:
        if isinstance(default, kind):
            return kind, getter, setter
    return str, "GetString", "SetString"


def get(key: str) -> Any:
    """Read one setting, falling back to its default on any error."""
    default = DEFAULTS[key]
    _kind, getter, _setter = _accessor(default)
    try:
        return getattr(_params(), getter)(key, default)
    except Exception:
        App.Console.PrintError("Nxt: could not read preference %r\n" % key)
        return default


def put(key: str, value: object) -> None:
    kind, _getter, setter = _accessor(DEFAULTS[key])
    try:
        getattr(_params(), setter)(key, kind(value))
    except Exception:
        App.Console.PrintError("Nxt: could not write preference %r\n" % key)
        App.Console.PrintError(traceback.format_exc())
