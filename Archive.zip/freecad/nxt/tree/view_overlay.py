"""The tree panel drawn inside the 3D view, clicks passing through.

Each press asks the QML whether it draws at that point (`wantsPoint`);
if not, the press and its moves and release go to the 3D view.
"""

from __future__ import annotations

from typing import Any

import FreeCAD as App

from ..core import view3d, widgets
from ..core.qt import QtCore, QtGui, QtWidgets
from ..core.qtquick import modules as _quick_modules

_PRESSES = (QtCore.QEvent.Type.MouseButtonPress,
            QtCore.QEvent.Type.MouseButtonDblClick)
_FOLLOWERS = (QtCore.QEvent.Type.MouseMove,
              QtCore.QEvent.Type.MouseButtonRelease)
#: What a 3D view window does on its way to being destroyed.
_GOING = (QtCore.QEvent.Type.Close, QtCore.QEvent.Type.DeferredDelete,
          QtCore.QEvent.Type.Hide)


class ViewOverlay(QtCore.QObject):
    """Moves the panel's view into the active 3D view and back."""

    def __init__(self, dock: Any) -> None:
        super().__init__(dock)
        self._dock = dock
        self._host: Any = None
        self._attached = False
        self._passing = False
        self._through = False
        self._owning = False
        #: The View3DInventor around `_host`, watched for closing.
        self._holder: Any = None
        self._parked = False
        self._retrying = False
        #: Explicitly hidden parent for the panel while no 3D view shows,
        #: so a workbench switch showing the dock cannot reveal it.
        self._shelf = QtWidgets.QWidget(dock)
        self._shelf.hide()

    def attached(self) -> bool:
        return self._attached

    def attach(self) -> bool:
        """Into the active 3D view, or out of sight until there is one."""
        view = self._dock._view
        if not widgets.alive(view):
            return False
        self._attached = True
        self._dock.setWidget(QtWidgets.QWidget())   # the view leaves it
        host = view3d.active_viewport()
        if host is not None:
            self._move_to(host)
        else:
            self._park()        # no 3D view yet: into the first one
        self._dock.hide()
        self._dock.installEventFilter(self)
        area = view3d.mdi_area()
        if area is not None:
            area.subWindowActivated.connect(self._follow)
        return True

    def detach(self) -> None:
        """Back into the dock."""
        if not self._attached:
            return
        self._attached = False
        self._dock.removeEventFilter(self)
        area = view3d.mdi_area()
        if area is not None:
            try:
                area.subWindowActivated.disconnect(self._follow)
            except (RuntimeError, TypeError):
                pass
        for old in (self._host, self._holder):
            if widgets.alive(old):
                old.removeEventFilter(self)
        self._host = self._holder = None
        self._passing = False
        self._owning = False
        self._parked = False
        view = self._dock._view
        if widgets.alive(view):
            self._set_through(False)
            view.removeEventFilter(self)
            view.setParent(None)
            self._dock.setWidget(view)
            view.show()
        self._dock.show()
        self._dock._release_timer.start()

    def _follow(self, *_args: Any) -> None:
        """Another MDI window became active: go with it, if it is 3D."""
        if not self._attached:
            return
        host = view3d.active_viewport()
        if host is None:
            self._park()
            # A just-activated 3D view may not have its GL widget yet.
            if not self._retrying:
                self._retrying = True
                for delay in (0, 150, 600):
                    QtCore.QTimer.singleShot(delay, self._retry)
        elif host is not self._host or self._parked:
            self._move_to(host)

    def _retry(self) -> None:
        self._retrying = False
        if not self._attached or not self._parked:
            return
        host = view3d.active_viewport()
        if host is not None:
            self._move_to(host)

    def _park(self) -> None:
        """Reparent the panel off a hiding 3D view so it is not destroyed."""
        view = self._dock._view
        if self._parked or not widgets.alive(view):
            return
        self._parked = True
        self._passing = False
        self._owning = False
        self._set_through(False)
        view.hide()
        view.setParent(self._shelf)

    def _move_to(self, host: Any) -> None:
        view = self._dock._view
        if not widgets.alive(view):
            return
        for old in (self._host, self._holder):
            if widgets.alive(old):
                old.removeEventFilter(self)
        self._host = host
        self._holder = view3d.view3d_holding(host)
        if self._holder is not None:
            self._holder.installEventFilter(self)
        self._parked = False
        self._set_through(False)
        # Host moves tell us the pointer is back over a pill while
        # the panel is mouse-transparent.
        host.setMouseTracking(True)
        view.setParent(host)
        view.setAttribute(QtCore.Qt.WidgetAttribute.WA_AlwaysStackOnTop,
                          True)
        host.installEventFilter(self)
        view.installEventFilter(self)
        self._passing = False
        self._owning = False
        self._place()
        view.show()
        view.raise_()
        self._dock._release_timer.start()

    def _keep_dock_hidden(self) -> None:
        if self._attached and widgets.alive(self._dock):
            self._dock.hide()

    def _place(self) -> None:
        view = self._dock._view
        if (not widgets.alive(view) or not widgets.alive(self._host)
                or self._parked):
            return
        view.setGeometry(0, 0, self._host.width(), self._host.height())

    def eventFilter(self, watched: Any, event: Any) -> bool:  # noqa: N802
        kind = event.type()
        try:
            if watched is self._dock:
                if kind == QtCore.QEvent.Type.Show:
                    # Workbench switches re-show remembered docks.
                    QtCore.QTimer.singleShot(0, self._keep_dock_hidden)
                return False
            if watched is self._holder and kind in _GOING:
                self._park()
                return False
            if watched is self._host:
                if kind == QtCore.QEvent.Type.MouseButtonRelease:
                    self._passing = False
                    self._owning = False
                if kind == QtCore.QEvent.Type.Hide:
                    self._park()
                elif kind == QtCore.QEvent.Type.Show and self._parked \
                        and self._host is view3d.active_viewport():
                    self._move_to(self._host)
                elif kind == QtCore.QEvent.Type.Resize:
                    self._place()
                elif kind in _PRESSES and not self._through \
                        and self._from_panel(event):
                    self._passing = True
                elif kind == QtCore.QEvent.Type.MouseMove \
                        and self._through and not event.buttons() \
                        and self._wants_at(self._in_view(event)):
                    self._set_through(False)
                return False
            if watched is self._dock._view \
                    and kind == QtCore.QEvent.Type.MouseMove \
                    and not event.buttons():
                # Clear flags whose release went elsewhere (e.g. to a
                # dialog the click opened).
                self._passing = self._owning = False
            if watched is self._dock._view \
                    and kind == QtCore.QEvent.Type.MouseMove \
                    and not event.buttons() \
                    and not self._wants_at(event.position()):
                self._set_through(True)
                return True
            if watched is self._dock._view \
                    and kind == QtCore.QEvent.Type.Wheel:
                # Forward explicitly: the scene may accept an unused wheel.
                if self._wants(event):
                    self._scroll(event)
                else:
                    self._pass_wheel(event)
                event.accept()
                return True
            if watched is self._dock._view and kind in _PRESSES:
                # Ask QML, not scene acceptance: tap handlers take part in
                # a press without accepting it.
                if self._wants(event):
                    self._passing = False
                    self._owning = True
                    self._deliver(event)
                    return True
                self._owning = False
                self._passing = True
                self._pass_on(event)
                return True
            if watched is self._dock._view and self._owning \
                    and kind in _FOLLOWERS:
                # Else an unaccepted release (a tap) reaches the 3D view
                # and changes the selection.
                self._deliver(event)
                if kind == QtCore.QEvent.Type.MouseButtonRelease \
                        and not event.buttons():
                    self._owning = False
                return True
            if watched is self._dock._view and self._passing \
                    and kind in _FOLLOWERS:
                self._pass_on(event)
                if kind == QtCore.QEvent.Type.MouseButtonRelease \
                        and not event.buttons():
                    self._passing = False
                    self._owning = False
                return True
        except Exception as exc:
            App.Console.PrintLog("Nxt view overlay: %s\n" % exc)
            self._passing = False
            self._owning = False
        return False

    def _scroll(self, event: Any) -> None:
        root = self._dock._view.rootObject()
        if root is None:
            return
        QtCore.QMetaObject.invokeMethod(
            root, "scrollWheel", QtCore.Qt.ConnectionType.DirectConnection,
            QtCore.Q_ARG("QVariant", float(event.angleDelta().y())),
            QtCore.Q_ARG("QVariant", float(event.pixelDelta().y())),
            QtCore.Q_ARG("QVariant", bool(
                event.modifiers() & QtCore.Qt.KeyboardModifier.ShiftModifier)))

    def _pass_wheel(self, event: Any) -> None:
        """Send the panel's wheel event to the 3D view, in its coordinates."""
        view, host = self._dock._view, self._host
        if not widgets.alive(host):
            return
        local = QtCore.QPointF(view.mapTo(host, event.position().toPoint()))
        forwarded = QtGui.QWheelEvent(
            local, event.globalPosition(), event.pixelDelta(),
            event.angleDelta(), event.buttons(), event.modifiers(),
            event.phase(), event.inverted(), event.source())
        QtWidgets.QApplication.sendEvent(host, forwarded)

    def _deliver(self, event: Any) -> None:
        """Give a mouse event to the panel only, never past it."""
        quick_widget = _quick_modules()[2].QQuickWidget
        quick_widget.event(self._dock._view, event)
        event.accept()

    def _set_through(self, on: bool) -> None:
        """Make the panel transparent to the mouse, or not.

        Lets the 3D view get hover (preselection) and wheel natively.
        """
        view = self._dock._view
        if on == self._through or not widgets.alive(view):
            return
        self._through = on
        view.setAttribute(
            QtCore.Qt.WidgetAttribute.WA_TransparentForMouseEvents, on)
        if on:
            # Clear row hover state.
            QtWidgets.QApplication.sendEvent(
                view, QtCore.QEvent(QtCore.QEvent.Type.Leave))

    def _in_view(self, event: Any) -> QtCore.QPointF:
        """A 3D view event's position in the panel's coordinates."""
        view = self._dock._view
        return QtCore.QPointF(view.mapFrom(self._host,
                                           event.position().toPoint()))

    def _wants(self, event: Any) -> bool:
        """Does the panel draw anything where this press is?"""
        return self._wants_at(event.position())

    def _wants_at(self, point: Any) -> bool:
        """Does the panel draw anything at this point, in its coordinates?"""
        view = self._dock._view
        root = view.rootObject() if widgets.alive(view) else None
        if root is None:
            return True
        try:
            return bool(QtCore.QMetaObject.invokeMethod(
                root, "wantsPoint",
                QtCore.Qt.ConnectionType.DirectConnection,
                QtCore.Q_RETURN_ARG("QVariant"),
                QtCore.Q_ARG("QVariant", point.x()),
                QtCore.Q_ARG("QVariant", point.y())))
        except Exception:
            return True

    def _from_panel(self, event: Any) -> bool:
        """Did this press reach the 3D view by passing through the panel?"""
        view = self._dock._view
        if view is None or not view.isVisible():
            return False
        return view.geometry().contains(event.position().toPoint())

    def _pass_on(self, event: Any) -> None:
        """Send the panel's mouse event to the 3D view, in its coordinates."""
        view, host = self._dock._view, self._host
        local = QtCore.QPointF(view.mapTo(host, event.position().toPoint()))
        forwarded = QtGui.QMouseEvent(
            event.type(), local, event.globalPosition(), event.button(),
            event.buttons(), event.modifiers())
        QtWidgets.QApplication.sendEvent(host, forwarded)
